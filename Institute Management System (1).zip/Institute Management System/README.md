Attendance_Tracker
==================

A web application which can be used by students to track their attendance and also inform the 
student when there is shortage of attendance.
