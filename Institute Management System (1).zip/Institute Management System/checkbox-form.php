<?php
if(isset($_POST['att']) &&
$_POST['att'] == 'Yes')
{
  echo "Present";
}
else
{
  echo "Absent";
}
?>
