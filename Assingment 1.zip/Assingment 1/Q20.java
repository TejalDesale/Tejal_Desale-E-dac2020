package Assingment1;

public class Q20 {
	public static void main(String args[]){  
		System.out.println(Integer.toHexString(15));  
		  
}
}