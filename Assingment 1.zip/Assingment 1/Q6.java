package Assingment1;

public class Q6 {

	public static void main(String[] args)
	{
		System.out.println(125+24);
		System.out.println(125-24);
		System.out.println(125*24);
		System.out.println(125/24);
		System.out.println(125%24);
	}

}
