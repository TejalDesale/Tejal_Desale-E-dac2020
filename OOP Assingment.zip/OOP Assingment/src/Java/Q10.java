package Java;
import java.util.Scanner;
public class Q10 {

	/*
	Write a program to convert temperature from Fahrenheit to Celsius. 
	Take Fahrenheit as input using Scanner class. [ formula : C= 5*(f-32)/9 ]
	 */
	
	    private static Scanner sc;

		public static void main(String[] args)
	    {
	     sc = new Scanner(System.in);
	     float f=sc.nextFloat();
	     float c= 5*(f-32)/9;
	     System.out.println("Celcius = "+c);
	    }
	    
	}

