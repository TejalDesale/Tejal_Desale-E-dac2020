package Java;

public class Q2 {

	/*
	Write a program to declare a variable named rollNo of integer type. Assign it a value (let say 100) to it
	and print the following statement roll no = 100 .
	 */
	
	    public static void main(String[] args)
	    {
	       int roll_no=100;
	       System.out.println("roll no="+ roll_no);
	    }
	    
	}

