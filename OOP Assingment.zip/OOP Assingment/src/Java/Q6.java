package Java;
import java.util.Scanner;

public class Q6 {

	private static Scanner sc;

	/*Write a program that takes radius of a circle as input. Read the entered radius using Scanner class.
	Then calculate and print the area and circumference of the circle.
	 */public static void main(String[] args)
	    {
	        sc = new Scanner(System.in);
	        double  radius=sc.nextInt();
	        double area=(3.14*(double)(Math.pow(radius,2)));
	         System.out.println(area);
	        
	        
	    }
	    
	}
