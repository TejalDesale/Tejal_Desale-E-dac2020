package Java;
import java.util.*;
public class Assingment06 {

	/*
	 Program to show sum and average of 10 element 
	array. Accept array elements from user. 
	 */
	/*
	 Program to show sum and average of 10 element 
	array. Accept array elements from user. 
	 */

	    private static Scanner sc;
		private static double remainder;

		public static void main(String[] args)
	    {
	        sc = new Scanner(System.in);
	        double[] array=new double[10]; 
	        for(int i=0;i<array.length;i++)
	        {
	        array[i]=sc.nextDouble();
	        }
	        double sum=0;
	        double average=0;
	        remainder = 0;
	        for(int i=0;i<array.length;i++)
	        {
	            sum+=array[i];
	            average=(sum/array.length);    
	        }
	        System.out.println("Total = " + sum);
	        System.out.println("Average = " + average);
	    }
	    
	}

