package Java;
import java.util.Scanner;
public class Assingment01 {

	/*
	  Write a program to print table of any entered number using loop.
	 */
	
	    private static Scanner sc;

		public static void main(String[] args)
	    {
	        sc = new Scanner(System.in);
	        int a=sc.nextInt();
	        for(int i=1;i<=10;i++)
	        {
	           int table=a*i;
	           System.out.println(a+ " x " +i +" = " +table);
	        }
	    }
	           
	    
	}

