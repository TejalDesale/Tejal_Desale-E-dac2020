package Java;
public class Q1 {

	public static void main(String[] args) {
		 
		System.out.println("Hello World");
		// TODO Auto-generated method stub

	}

}